//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 1.0
//  \   \        Filename: $RCSfile: c_model.c,v $
//  /   /        Date Last Modified: $Date: 2012/02/02 06:55:46 $
// /___/   /\    Date Created: 2012
// \   \  /  \
//  \___\/\___\
//
// Device  : All
// Purpose : Stimuli and Golden Results generator module,
//           To be shared between c_model and run_bitacc_cmodel
//-----------------------------------------------------------------------------
//  (c) Copyright 2012 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES.
//-------------------------------------------------------------------
// Description:
//
// This wrapper file creates Input test files and
// Golden results by running the C model on the input files
//
// Uses a portable random number generator rather than the C rand()
// function, to give the same results on all platforms.  This permits
// rerunning on any platform when debugging failing tests.
//-------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include "bmp_utils.h"
#include "rgb_utils.h"
#include "gen_stim.h"
#include "v_cfa_v7_0_bitacc_cmodel.h"

#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#pragma warning( disable : 4996 )

#ifndef _MAX_FRAMES
#define _MAX_FRAMES 32
#endif

#ifndef uint32
#define uint32 unsigned int
#endif

const double MAX_DWORD= 65536.0 * 65536.0 ;
int printwide(FILE* output_txt, double value, int line_feed)
{
    double dw_lo, dw_hi;

    dw_hi = floor(value / MAX_DWORD);
    dw_lo = value - dw_hi * MAX_DWORD;

    return( (fprintf(output_txt," %04X%08X%s", (uint32) dw_hi, (uint32) dw_lo, (line_feed>0) ? "\r\n" : ""))<2 );
}

// Create stimuli and results directories under the path specified. Optionally clean directory if dir already exists
int prep_dirs(char *data_path, int clean)
{
  char command[MAX_PATH] = { 0 };
  char in_path[MAX_PATH] = { 0 };
  char out_path[MAX_PATH] = { 0 };
  char *c;
  int  ret_val;

  sprintf(in_path, "stimuli");
  sprintf(out_path, "result");

  sprintf(command, "cd %s", in_path);
  if ((ret_val=system(command)==0) && (clean>0)) {
    printf("Stimuli directory already exists. Removing all possible .bmp and .txt source files.\n");
      sprintf(command, "%s %s%c*.bmp", RM_COMMAND, in_path, SLASH);
    system(command);
      sprintf(command, "%s %s%c*.txt", RM_COMMAND, in_path, SLASH);
    system(command);
  }
  else {
    printf("Creating stimuli directory under data_path.\n");
    if (SLASH!='/')
      for (c=in_path; *c!=0; c++)
        if (*c=='/') *c='\\';
    sprintf(command, "mkdir %s", in_path);
    if ((ret_val=system(command)>0)) {
      printf("Could not create stimuli directory for input file!\n\n");
      return ret_val;
    }
  }

  // Create result directory under the path specified. Optionally, if directory exists, clean it:
  sprintf(command, "cd %s", out_path);
  if ((ret_val=system(command)==0) && (clean>0)) {
    printf("Directory already exists. Removing all possible .bmp and .txt source files.\n");
      sprintf(command, "%s %s%c*.bmp", RM_COMMAND, out_path, SLASH);
    system(command);
      sprintf(command, "%s %s%c*.txt", RM_COMMAND, out_path, SLASH);
    system(command);
  }
  else {
    printf("Creating result directory under path specified.\n");
    sprintf(command, "mkdir %s", out_path);
    if ((ret_val=system(command)>0)) {
      printf("Could not create stimuli directory for input file!\n\n");
      return ret_val;
    }
  }
  return(0);
}

int gen_stim(       struct xilinx_ip_v_cfa_v7_0_generics *cfa_generics,
                    struct xilinx_ip_v_cfa_v7_0_inputs   *cfa_inputs,
                    char *bmp_filename, char *data_path, int NFRAMES,
                    int transaction_id, int RAND_ORIG)
{
  FILE* input_bmp=NULL;
  FILE* output_bmp=NULL;
  FILE* input_txt=NULL;
  FILE* output_txt=NULL;
  char  in_txt_filename[MAX_PATH];
  char  out_txt_filename[MAX_PATH];
  char  out_bmp_filename[MAX_PATH];
  char  line[MAX_PATH];
  int   ret_val = 2;     // Corresponds to memory allocation error
  int   numread=0, frame;
  int   y_phase, x_phase;
  int   row, col, offsx, offsy;
  static struct rgb8_video_struct rgb8_in_video;
  static struct rgb8_video_struct rgb8_out_video;
  struct xilinx_ip_v_cfa_v7_0_outputs cfa_outputs[_MAX_FRAMES];

  // Indicate that dynamic frame buffers are initially unallocated:
  rgb8_in_video.r = NULL;
  rgb8_out_video.r = NULL;
  cfa_inputs->video_in.data[0] = NULL;
  cfa_outputs->video_out.data[0] = NULL;

  // Open input BMP file
  sprintf( line, "%s%s", data_path, bmp_filename);
  if ( (input_bmp = fopen(line, "rb" )) == NULL ) { printf( "Could not open input bmp file: %s!\n", line ); return(4); }

  // Read BMP file contents into the input frame buffer:
  if (read_bmp(input_bmp, &rgb8_in_video)>0) { ret_val=64; goto rgb_cleanup; }

  cfa_inputs->video_in.frames              = NFRAMES ;
  cfa_inputs->video_in.rows                = cfa_inputs->active_rows;
  cfa_inputs->video_in.cols                = cfa_inputs->active_cols;
  cfa_inputs->video_in.bits_per_component  = cfa_generics->DATA_WIDTH;
  cfa_inputs->video_in.mode                = FORMAT_MONO;

  y_phase = cfa_inputs->bayer_phase >> 1;
  x_phase = cfa_inputs->bayer_phase & 1;

  if (alloc_video_buff( &cfa_inputs->video_in )>0) return(1);  // Could not allocate frame buffer

  for (frame=0; frame<NFRAMES; frame++) {
    offsy=(RAND_ORIG) ? rand() : 0;   // Slice out a video_in.rows by video_in.cols rectangle from the input image
    offsx=(RAND_ORIG) ? rand() : 0;   // The top left corner location is randomized. The actual image created is cropped from an infinite plane tiled with the input bmp


    for (row=0; row<cfa_inputs->video_in.rows; row++) {
      for (col=0; col<cfa_inputs->video_in.cols; col++) {
        switch (2*(y_phase ^ (row&1)) + (x_phase ^ (col&1)))    // Bayer sub-sampling according to x and y phase:
        {
          case 0:   { cfa_inputs->video_in.data[0][frame][row][col] = rgb8_in_video.r[0][(row+offsy) % rgb8_in_video.rows][(col+offsx) % rgb8_in_video.cols]; break; }
          case 3:   { cfa_inputs->video_in.data[0][frame][row][col] = rgb8_in_video.b[0][(row+offsy) % rgb8_in_video.rows][(col+offsx) % rgb8_in_video.cols]; break; }
          default:  { cfa_inputs->video_in.data[0][frame][row][col] = rgb8_in_video.g[0][(row+offsy) % rgb8_in_video.rows][(col+offsx) % rgb8_in_video.cols]; break; }
        }
        // turn input video to 12 bits per color channel in order to test wide data processing:
        if (cfa_generics->DATA_WIDTH > 8)
          cfa_inputs->video_in.data[0][frame][row][col] <<=  (cfa_generics->DATA_WIDTH-8);
          cfa_inputs->video_in.data[0][frame][row][col] += ((row + col) & ((1<<(cfa_generics->DATA_WIDTH-8))-1));
      }
    }
  }

  if (transaction_id==1) prep_dirs(data_path, 1);

  // For the test-bench,  the wide data stimuli and results are written as .txt files:
  sprintf(in_txt_filename, "stimuli%cs0_tr_%d.txt", SLASH, transaction_id);
  sprintf(out_txt_filename, "result%cm0_tr_%d.txt", SLASH, transaction_id);

  // write stimuli data to txt file so the Test-bench or MATLAB can work with the same data
  if ( (input_txt = fopen(in_txt_filename, "wb")) == NULL ) {
    printf( "Could not write stimuli txt file\n" ); ret_val = 16; goto rgb_cleanup; }

  printf("Writing Stimuli TXT file for transaction %d\n", transaction_id);
  if (WriteVideoTxtFile(input_txt, &(cfa_inputs->video_in), -1, 0, 0)>0) {
    printf("Error while writing Stimuli TXT file for transaction %d\n", transaction_id);
    ret_val=128; goto rgb_cleanup; }

  //  Execute CFA Model
  printf("Executing CFA C model transaction %d\n", transaction_id);
  if (xilinx_ip_v_cfa_v7_0_bitacc_simulate( cfa_generics, cfa_inputs, cfa_outputs ) > 0) {
    printf("Error while executing CFA C model transaction %d\n", transaction_id);
    goto rgb_cleanup;}

  // write stimuli data to txt file so the Test-bench or MATLAB can work with the same data
  if ( (output_txt = fopen(out_txt_filename, "wb")) == NULL ) {
    printf( "Could not write result txt file\n" ); ret_val = 96; goto rgb_cleanup; }

  printf("Writing Result TXT file for transaction %d\n", transaction_id);
  if (WriteVideoTxtFile(output_txt, &(cfa_outputs->video_out), -1, 0, 0)>0) {
    printf("Error while writing Result TXT file for transaction %d\n", transaction_id);
    ret_val=256; goto rgb_cleanup; }

  for (frame=0; frame<NFRAMES; frame++)
    if (copy_video_to_rgb8_fl( &(cfa_outputs->video_out), &rgb8_out_video, frame, frame) ==0) {
      sprintf(out_bmp_filename, "%sresult%cm0_tr_%d_fr_%03d.bmp", data_path, SLASH, transaction_id, frame);
      if ( (output_bmp = fopen(out_bmp_filename, "wb")) != NULL ) {
        printf("Writing result BMP file %d for transaction %d\n", frame, transaction_id);
        write_bmp(output_bmp, &rgb8_out_video);
        fclose(output_bmp);
        free_rgb_frame_buff((struct rgb8_video_struct*) &rgb8_out_video);
      }
    }

  ret_val = 0;

  rgb_cleanup:
  if (rgb8_in_video.r>0)   free_rgb_frame_buff((struct rgb8_video_struct*) &rgb8_in_video);
  xilinx_ip_v_cfa_v7_0_destroy(cfa_inputs, cfa_outputs);
  if (input_bmp>0) fclose(input_bmp);
  if (input_txt>0) fclose(input_txt);
  if (output_txt>0) fclose(output_txt);
  return ret_val;
}

