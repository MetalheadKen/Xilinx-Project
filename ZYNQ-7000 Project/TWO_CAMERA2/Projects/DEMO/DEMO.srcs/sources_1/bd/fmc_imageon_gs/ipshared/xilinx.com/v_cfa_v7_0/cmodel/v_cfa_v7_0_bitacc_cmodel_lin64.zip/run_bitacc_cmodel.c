//  (c) Copyright 2010 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
////////////////////////////////////////////////////////////
/* Include files */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include "v_cfa_v7_0_bitacc_cmodel.h"
#include "gen_stim.h"

#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#pragma warning( disable : 4996 )

#ifndef MAX_PATH
#define MAX_PATH 2048
#endif

int print_help(void)
{
  printf("\nUsage: v_cfa_v7_0_bitacc_cmodel data_path input_bmp\n\n");
  printf("       data_path     : path to the input BMP file. result and stimuli directories will be created here.\n");  
  printf("       input_bmp     : name of the input  BMP file, with extension .bmp\n\n");
  return(0);
}


int main( int argc, char* argv[] )
{
  char in_filename[MAX_PATH] = { 0 }; 
  char data_path[MAX_PATH] = { 0 }; 
  char in_ext[16];
  char *c;
  int ret_val, len;
  int NFRAMES=1;
  int RAND_ORIG=2;    // Instructs the stimuli generator to randomly shift the input bmp image before Bayer sub-sampling

  struct  xilinx_ip_v_cfa_v7_0_generics cfa_generics;
  struct  xilinx_ip_v_cfa_v7_0_inputs   cfa_inputs;

  if ((ret_val = xilinx_ip_v_cfa_v7_0_get_default_generics(&cfa_generics))>0) return(ret_val);

  if (argc<3) exit(print_help()); 

  if ((ret_val = xilinx_ip_v_cfa_v7_0_get_default_inputs(&cfa_generics, &cfa_inputs))>0) return(ret_val);

  // Demonstrates how to set inputs or generics before calling the CFA model
  // Generics reflect parameterization via the GUI
  // Inputs reflect application sofware register settings via the AXI4-Lite control interface
  cfa_inputs.active_cols = 320;
  cfa_inputs.active_rows = 240;
  cfa_inputs.bayer_phase = 2;

  // If the active sizes programmed into the ACTIVE_SIZE register of the CFA are different from the dimensions
  // of the input bmp,the stimuli generator intelligently crops or tiles the ACTIVE_SIZE image with the input bmp.
  strcpy(data_path, argv[1]);
  strcpy(in_filename,  argv[2]);

  // Replace forward slashes with back slashes on Windows:
  if (SLASH!='/') for (c=data_path; *c!=0; c++) { if (*c=='/') *c='\\'; }
  
  // Terminate path with slash, if missing:
  len = (int) strlen(data_path);
  if ((data_path[len-1] != '/') && (data_path[len-1] != '\\')) 
    { data_path[len]=SLASH; data_path[len+1]=0; }

  strcpy( in_ext, strrchr(in_filename,'.')+1 );
  for (c=in_ext; *c!=0; c++) tolower( *c );

  if (strcmp(in_ext, "bmp")==0) 
      gen_stim( &cfa_generics, &cfa_inputs, in_filename, data_path, NFRAMES, 1, RAND_ORIG);
  else { printf("\nInput file format not recognized!\n"); return(16);  }
  return(0);
}
