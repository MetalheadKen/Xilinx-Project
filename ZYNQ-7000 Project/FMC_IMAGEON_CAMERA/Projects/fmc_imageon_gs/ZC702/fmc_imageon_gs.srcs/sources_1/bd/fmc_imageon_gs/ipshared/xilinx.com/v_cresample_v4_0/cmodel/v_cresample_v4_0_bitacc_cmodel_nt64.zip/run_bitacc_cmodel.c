//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 1.0
//  \   \        Filename: $RCSfile: $
//  /   /        Date Last Modified: $Date: $
// /___/   /\    Date Created: 2011
// \   \  /  \
//  \___\/\___\
//
// Devices : All
// Library : Image and Video Processing
// Purpose : 
//-----------------------------------------------------------------------------
//  (c) Copyright 2011 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-----------------------------------------------------------------------------

/* Include files */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include "video_utils.h"
#include "bmp_utils.h"
#include "rgb_utils.h"
#include "yuv_utils.h"
#include "parsers.h"
#include "v_cresample_v4_0_bitacc_cmodel.h"

#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#pragma warning( disable : 4996 )

#ifdef NT
#define SLASH '\\'
#else
#ifdef _WIN32
#define SLASH '\\'
#else
#define SLASH '/'
#endif
#endif

#ifndef _MAX_PATH
#define _MAX_PATH 2048
#endif

#ifndef uint32
#define uint32 unsigned int
#endif

struct  xilinx_ip_v_cresample_v4_0_generics cresample_generics;
struct  xilinx_ip_v_cresample_v4_0_inputs   cresample_inputs;
struct  xilinx_ip_v_cresample_v4_0_outputs  cresample_outputs;
struct  CFG_VARIABLES cfg_variables;
struct  XCO_VARIABLES xco_variables;

char    in_path[_MAX_PATH] = { 0 }; 
char    out_path[_MAX_PATH] = { 0 }; 
char    in_filename[_MAX_PATH] = { 0 }; 
char    out_filename[_MAX_PATH] = { 0 }; 

int yuv_processing(char* in_filename, char* out_filename)
{
  FILE* input_yuv=NULL; 
  FILE* output_yuv=NULL;

  struct yuv8_video_struct in_yuv;
  struct yuv8_video_struct out_yuv;
  int  ret_val = 2;     // Corresponds to memory allocation error

  // Indicate that dynamic frame buffers are initially unallocated:
  cresample_inputs.video_in.data[0] = NULL;
  cresample_outputs.video_out.data[0] = NULL;
  in_yuv.y = NULL; in_yuv.u = NULL; in_yuv.v = NULL; 
  out_yuv.y = NULL; out_yuv.u = NULL; out_yuv.v = NULL; 

  in_yuv.bits_per_component = cresample_generics.S_AXIS_VIDEO_DATA_WIDTH;
  in_yuv.chroma_format = cresample_generics.S_AXIS_VIDEO_FORMAT;
  in_yuv.cols = cfg_variables.number_of_cols;
  in_yuv.rows = cfg_variables.number_of_rows;
  in_yuv.frames = cfg_variables.number_of_frames;
  if ( (ret_val=alloc_yuv8_frame_buff(&in_yuv)) >0 ) { printf( "Could not allocate memory for input yuv file: %s!\n", in_filename ); return(ret_val); }  
  
  // Open input YUV file
  if ( (input_yuv = fopen(in_filename, "rb" )) == NULL ) { printf( "Could not open input yuv file: %s!\n", in_filename ); return(4); }

  // Read .yuv file contents into the input frame buffer: 
  if (read_yuv8(input_yuv, &in_yuv)>0) { ret_val=64; goto cleanup_yuv; }
  if (copy_yuv8_to_video(&in_yuv, &cresample_inputs.video_in)>0) { ret_val=64; goto cleanup_yuv; }

  //  Execute Chroma Resampler model: 
  if (xilinx_ip_v_cresample_v4_0_bitacc_simulate( &cresample_generics, &cresample_inputs, &cresample_outputs ) > 0)  { goto cleanup_yuv; }

  // write result video to yuv file
  if (copy_video_to_yuv8(&cresample_outputs.video_out, &out_yuv)>0) { ret_val=64; goto cleanup_yuv; }
  if ( (output_yuv = fopen(out_filename, "w+b")) == NULL ) { printf( "Could not open output yuv file\n" ); ret_val = 0x20; goto cleanup_yuv; }
  if (write_yuv8(output_yuv, &out_yuv)>0) { ret_val=0x21; goto cleanup_yuv; }

  ret_val = 0;
  
  cleanup_yuv:   
  printf("Flushing and closing files\n");
  if (input_yuv>0) {fclose(input_yuv);}
  if (output_yuv>0) {fclose(output_yuv);}
  printf("Releasing memory\n");
  if (in_yuv.y>0)   {free_yuv8_frame_buff( &in_yuv );}
  if (out_yuv.y>0)  {free_yuv8_frame_buff( &out_yuv );}
  if (cresample_inputs.video_in.data[0]>0)  {free_video_buff( &cresample_inputs.video_in);}
  if (cresample_outputs.video_out.data[0]>0) {free_video_buff( &cresample_outputs.video_out);}
  printf("Done.\n");
  return ret_val;
}

int bin_processing(char* in_filename, char* out_filename)
{
  FILE* input_bin=NULL; 
  FILE* output_bin=NULL;
  int  ret_val = 2;     // Corresponds to memory allocation error

  // Indicate that dynamic frame buffers are initially unallocated:
  cresample_inputs.video_in.data[0] = NULL;
  cresample_outputs.video_out.data[0] = NULL;
  
  // Open input BIN file
  if ( (input_bin = fopen(in_filename, "rb" )) == NULL ) { printf( "Could not open input bin file!\n" ); return(4); }

  // Read .bin file contents into the input frame buffer:
  if (read_video(input_bin, &cresample_inputs.video_in)>0) { ret_val=64; goto cleanup_bin; }

  //  Execute Chroma Resampler model: 
  if (xilinx_ip_v_cresample_v4_0_bitacc_simulate( &cresample_generics, &cresample_inputs, &cresample_outputs ) > 0) { goto cleanup_bin; }

  // write result video to bin file
  if ( (output_bin = fopen(out_filename, "w+b")) == NULL ) { printf( "Could not open output bin file\n" ); ret_val = 0x20; goto cleanup_bin; }
  if (write_video(output_bin, &cresample_outputs.video_out)>0) { ret_val=0x21; goto cleanup_bin; }

  ret_val = 0;
  
  cleanup_bin:   
  printf("Flushing and closing files\n");
  if (input_bin>0) { fclose(input_bin); }
  if (output_bin>0)  {fclose(output_bin); }
  printf("Releasing memory\n");
  if (cresample_inputs.video_in.data[0]>0) { free_video_buff( &cresample_inputs.video_in); }
  if (cresample_outputs.video_out.data[0]>0) { free_video_buff( &cresample_outputs.video_out); }
  printf("Done.\n");
  return ret_val;
}

int print_help(void)
{
  printf("\nUsage: run_bitacc_cmodel file_dir config_file.cfg \n\n");
  printf("       file_dir : path to the location of the input/output files\n\n");
  printf("       config_file : name of the configuration file\n\n");
  return(0);
}

int main( int argc, char* argv[] )
{
  char cfg_filename[_MAX_PATH] = { 0 }; 
  char in_ext[16];
  char* c;
  int ret_val;
  int i;

  if ((ret_val = xilinx_ip_v_cresample_v4_0_get_default_generics(&cresample_generics))>0) {return(ret_val);}
  if (argc!=3) exit(print_help()); 

  strcpy(in_path, argv[1]); strcat (in_path, "/");
  strcpy(out_path, argv[1]); strcat (out_path, "/");
  strcpy(cfg_filename, argv[1]); strcat (cfg_filename, "/"); strcat(cfg_filename, argv[2]);

  // Initialize generics and inputs structure:
  //if ((ret_val = xilinx_ip_v_cresample_v4_0_get_default_generics(&cresample_generics))>0) {return(ret_val);}
  if ((ret_val = xilinx_ip_v_cresample_v4_0_get_default_inputs(&cresample_generics, &cresample_inputs))>0) {return(ret_val);}
  
  // Read the CFG file and populate the C model generics structure based on the parsed CFG file
  if ( (ret_val = read_XCO(cfg_filename, &xco_variables))>0 ) {return(ret_val);}
  cresample_generics.S_AXIS_VIDEO_FORMAT		= xco_variables.S_AXIS_VIDEO_FORMAT;
  cresample_generics.M_AXIS_VIDEO_FORMAT		= xco_variables.M_AXIS_VIDEO_FORMAT;
  cresample_generics.INTERLACED					= xco_variables.INTERLACED;
  cresample_generics.NUM_H_TAPS					= xco_variables.NUM_H_TAPS;
  cresample_generics.NUM_V_TAPS					= xco_variables.NUM_V_TAPS;
  cresample_generics.CONVERT_TYPE				= xco_variables.CONVERT_TYPE;
  cresample_generics.S_AXIS_VIDEO_DATA_WIDTH	= xco_variables.S_AXIS_VIDEO_DATA_WIDTH;
  cresample_generics.ACTIVE_COLS				= xco_variables.ACTIVE_COLS;
  cresample_generics.ACTIVE_ROWS				= xco_variables.ACTIVE_ROWS;
  cresample_generics.CHROMA_PARITY				= xco_variables.CHROMA_PARITY;
  cresample_generics.FIELD_PARITY				= xco_variables.FIELD_PARITY;

  // Read the CFG file and populate the variables governing filtering behavior:
  if ( (ret_val = read_CFG(cfg_filename, &cfg_variables))>0 ) {return(ret_val);}

  for (i=0; i<24; i++) {
    cresample_inputs.coefs_hphase0[i]  = cfg_variables.coef_hphase0[i];
    cresample_inputs.coefs_hphase1[i]  = cfg_variables.coef_hphase1[i]; }
  for (i=0; i<8; i++) {
    cresample_inputs.coefs_vphase0[i]  = cfg_variables.coef_vphase0[i];
    cresample_inputs.coefs_vphase1[i]  = cfg_variables.coef_vphase1[i]; }

  strcpy( in_ext, strrchr(cfg_variables.input_file_name,'.')+1 );
  for (c=in_ext; *c!=0; c++) {tolower( *c );}

  strcpy( in_filename,   in_path); strcat( in_filename,  cfg_variables.input_file_name);
  strcpy( out_filename, out_path); strcat( out_filename, cfg_variables.output_file_name);
  
  if      (strcmp(in_ext, "yuv")==0) {return(yuv_processing(in_filename, out_filename));}
  else if (strcmp(in_ext, "bin")==0) {return(bin_processing(in_filename, out_filename));}
  else { printf("\nInput file format has to be .yuv or .bin\n"); return(16);  }
  return(0);
}
