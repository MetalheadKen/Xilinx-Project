//
//  (c) Copyright 2011 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-------------------------------------------------------------------

#ifndef v_cresample_v4_0_bitacc_cmodel_h
#define v_cresample_v4_0_bitacc_cmodel_h

#ifdef NT
#define DLLIMPORT __declspec(dllimport)
#else
#define DLLIMPORT
#endif

#ifndef Ip_xilinx_ip_v_cresample_v4_0_DLL
#define Ip_xilinx_ip_v_cresample_v4_0_DLL DLLIMPORT
#endif

#ifdef  __cplusplus
extern "C" {
#endif

#ifndef rgb_utils_h
#include "rgb_utils.h"
#endif


#ifndef yuv_utils_h
#include "yuv_utils.h"
#endif

#ifndef video_utils_h
#include "video_utils.h"
#endif


struct xilinx_ip_v_cresample_v4_0_generics
{
  /**
   * Chroma Resampler v3.00.a Core Generics
   * These are the only generics that influence the operation of this bit-accurate model.
   */
  int S_AXIS_VIDEO_FORMAT;
  int M_AXIS_VIDEO_FORMAT;
  int INTERLACED;
  int NUM_H_TAPS;
  int NUM_V_TAPS;
  int CONVERT_TYPE;
  int S_AXIS_VIDEO_DATA_WIDTH;
  int COEF_WIDTH;
  int ACTIVE_COLS;
  int ACTIVE_ROWS;
  int FIELD_PARITY;
  int CHROMA_PARITY;
}; // xilinx_ip_v_cresample_v4_0_generics


/**
 * Get list of default generics.
 *
 * @returns xilinx_ip_v_cresample_v4_0_generics  Default generics.
 */
Ip_xilinx_ip_v_cresample_v4_0_DLL int xilinx_ip_v_cresample_v4_0_get_default_generics(struct xilinx_ip_v_cresample_v4_0_generics *generics);

/**
 * Get list of default inputs.
 *
 * @returns 0 if successful, error code otherwise.
 */
Ip_xilinx_ip_v_cresample_v4_0_DLL int xilinx_ip_v_cresample_v4_0_get_default_inputs(struct xilinx_ip_v_cresample_v4_0_generics *generics, struct xilinx_ip_v_cresample_v4_0_inputs *inputs);

/**
 * Structure to capture all inputs to the Chroma Resampler C-Model.
 *
 * @param video_in          Input data and formatting, provided as a pointer to video_struct.
 *                          Video_struct elements are:
 *                          data[color_channel][frame][row][col] containing 16 bit unsigned elements.
 *                          frames: number of frames in the data structure
 *                          rows  : number of rows in the data structure
 *                          cols  : number of columns in the data structure
 *                          bits_per_component: number of bits stored per pixel (use value 24 for 8 bits/color channel)
 *                          The user is responsible for properly allocating the data field, and initializing all fields 
 *                          of the video_struct.
 * 
 */
struct xilinx_ip_v_cresample_v4_0_inputs
{
  struct   video_struct video_in; //@- Contains the input data and formatting (frames, rows, color)
  float    coefs_hphase0[24];
  float    coefs_hphase1[24];
  float    coefs_vphase0[8];
  float    coefs_vphase1[8];

}; // end xilinx_ip_v_cresample_v4_0_inputs

/**
 * Structure to capture all outputs from the Chroma Resampler C-Model.
 *
 * Before using this structure the user is responsible defining the output video_struct.
 * If the data structure in the output video_struct is preallocated, the C-Model 
 * automatically uses the preallocated memory, but checks whether the formatting 
 * of the output video_stuct (number of frames, rows, columns) is compatible with the 
 * corresponding parameters of the input video_struct.
 *
 * @param video_out      Output data and formatting, provided as a pointer to video_struct.
 *                       Video_struct elements are:
 *                       data[color_channel][frame][row][col] containing 16 bit unsigned elements.
 *                       frames: number of frames in the data structure
 *                       rows  : number of rows in the data structure
 *                       cols  : number of columns in the data structure
 *                       bits_per_component: number of bits stored per pixel (use value 24 for 8 bits/color channel)
 */
struct xilinx_ip_v_cresample_v4_0_outputs
{
  struct video_struct video_out;  //@- Contains the output data and formatting (frames, rows, color)
}; // xilinx_ip_v_cresample_v4_0_outputs


/**
 * Simulate this bit-accurate C-Model.
 *
 * @param     generics   Inputs to the C-Model specified through Core Generator Generics
 * @param     inputs     Inputs to the C-Model specified through signals
 * @param     outputs    Outputs from this C-Model.
 *
 * @returns   Exit code   Zero for SUCCESS, Non-zero otherwise.
 */
Ip_xilinx_ip_v_cresample_v4_0_DLL
int xilinx_ip_v_cresample_v4_0_bitacc_simulate(
 struct xilinx_ip_v_cresample_v4_0_generics* generics,
 struct xilinx_ip_v_cresample_v4_0_inputs*   inputs,
 struct xilinx_ip_v_cresample_v4_0_outputs*  outputs);


#ifdef  __cplusplus
}
#endif

#endif // v_cresample_v4_0_bitacc_cmodel_h 


