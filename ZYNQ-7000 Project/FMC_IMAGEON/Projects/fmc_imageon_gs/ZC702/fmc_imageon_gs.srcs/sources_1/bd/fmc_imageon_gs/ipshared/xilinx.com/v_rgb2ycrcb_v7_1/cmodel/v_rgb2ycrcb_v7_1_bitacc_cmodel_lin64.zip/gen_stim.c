//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 1.0
//  \   \        Filename: $RCSfile: c_model.c,v $
//  /   /        Date Last Modified: $Date: 2011/01/15 file23:41:32 $
// /___/   /\    Date Created: 2010
// \   \  /  \
//  \___\/\___\
//
// Devices : All
// Library : Image and Video Processing
// Purpose : 
//-----------------------------------------------------------------------------
//  (c) Copyright 2011 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-----------------------------------------------------------------------------

/* Include files */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include "video_utils.h"
#include "bmp_utils.h"
#include "rgb_utils.h"
#include "yuv_utils.h"
#include "parsers.h"
#include "v_rgb2ycrcb_v7_1_bitacc_cmodel.h"
#include "gen_stim.h"


#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#pragma warning( disable : 4996 )

#ifndef _MAX_FRAMES
#define _MAX_FRAMES 32
#endif

#ifndef uint32
#define uint32 unsigned int
#endif

extern int RAND_ORIG;

#ifdef NT
#define SLASH '\\'
#define REMOVE "del"
#else
#ifdef _WIN32
#define SLASH '\\'
#define REMOVE "del"
#else
#define SLASH '/'
#define REMOVE "rm"
#endif
#endif

#ifndef _MAX_PATH
#define _MAX_PATH 2048
#endif

#ifndef uint32
#define uint32 unsigned int
#endif

int set_standard_generics(struct xilinx_ip_v_rgb2ycrcb_v7_1_generics *generics)
{
  double acoef[4][3] = {0.299, 0.299,  0.2568, 0.299, 0.299,  0.2568, 0.2126, 0.2126, 0.1819, 0.299,    0.299,    0.299};
  double bcoef[4][3] = {0.114, 0.114,  0.0979, 0.114, 0.114,  0.0979, 0.0722, 0.0722, 0.0618, 0.114,    0.114,    0.114};
  double ccoef[4][3] = {0.713, 0.7295, 0.5910, 0.713, 0.7295, 0.5910, 0.6350, 0.6495, 0.6495, 0.877283, 0.877283, 0.877283};
  double dcoef[4][3] = {0.564, 0.5772, 0.5772, 0.564, 0.5772, 0.5772, 0.5389, 0.5512, 0.5512, 0.492111, 0.492111, 0.492111};
  int yoffset = 1<<(generics->COEF_IN.IWIDTH-4);
  int coffset = 1<<(generics->COEF_IN.IWIDTH-1);
  int ymax[3] = {(240*(1<<(generics->COEF_IN.IWIDTH-8))), (235*(1<<(generics->COEF_IN.IWIDTH-8))), ((1<<generics->COEF_IN.IWIDTH)-1)};
  int ymin[3] = { (16*(1<<(generics->COEF_IN.IWIDTH-8))),  (16*(1<<(generics->COEF_IN.IWIDTH-8))), 0};
  int cbmax[3] = {(240*(1<<(generics->COEF_IN.IWIDTH-8))), (235*(1<<(generics->COEF_IN.IWIDTH-8))), ((1<<generics->COEF_IN.IWIDTH)-1)};
  int cbmin[3] = { (16*(1<<(generics->COEF_IN.IWIDTH-8))),  (16*(1<<(generics->COEF_IN.IWIDTH-8))), 0};
  int crmax[3] = {(240*(1<<(generics->COEF_IN.IWIDTH-8))), (235*(1<<(generics->COEF_IN.IWIDTH-8))), ((1<<generics->COEF_IN.IWIDTH)-1)};
  int crmin[3] = { (16*(1<<(generics->COEF_IN.IWIDTH-8))),  (16*(1<<(generics->COEF_IN.IWIDTH-8))), 0};

  if (generics->STANDARD_SEL == 4) { return 0; }  // Make no changes if Standard Select = Custom
  
  generics->COEF_IN.ACOEF = acoef[generics->STANDARD_SEL][generics->OUTPUT_RANGE];
  generics->COEF_IN.BCOEF = bcoef[generics->STANDARD_SEL][generics->OUTPUT_RANGE];
  generics->COEF_IN.CCOEF = ccoef[generics->STANDARD_SEL][generics->OUTPUT_RANGE];
  generics->COEF_IN.DCOEF = dcoef[generics->STANDARD_SEL][generics->OUTPUT_RANGE];
  generics->COEF_IN.YOFFSET  = yoffset;
  generics->COEF_IN.CBOFFSET = coffset;
  generics->COEF_IN.CROFFSET = coffset;
  generics->YMAX = ymax[generics->OUTPUT_RANGE];
  generics->YMIN = ymin[generics->OUTPUT_RANGE];
  generics->CBMAX = cbmax[generics->OUTPUT_RANGE];
  generics->CBMIN = cbmin[generics->OUTPUT_RANGE];
  generics->CRMAX = crmax[generics->OUTPUT_RANGE];
  generics->CRMIN = crmin[generics->OUTPUT_RANGE];
  generics->HAS_CLIP = 1;
  generics->HAS_CLAMP = 1;

  return 0;
}

// Create stimuli and results directories under the path specified. Optionally clean directory if dir already exists
int prep_dirs(char *data_path, int clean)
{
  char command[_MAX_PATH] = { 0 }; 
  char in_path[_MAX_PATH] = { 0 }; 
  char out_path[_MAX_PATH] = { 0 }; 
  char *c;
  int  ret_val;

  sprintf(in_path, "%sstimuli", data_path);
  sprintf(out_path, "%sexpected", data_path);

  sprintf(command, "cd %s", in_path);
  if ((ret_val=system(command)==0) && (clean>0)) {
    printf("Stimuli directory already exists. Removing all possible .bmp and .txt source files.\n");
    sprintf(command, "%s %s%c*.bmp", RM_COMMAND, in_path, SLASH); 
    system(command);
    sprintf(command, "%s %s%c*.txt", RM_COMMAND, in_path, SLASH); 
    system(command);
  }
  else {
    printf("Creating stimuli directory under data_path.\n");
    if (SLASH!='/') 
      for (c=in_path; *c!=0; c++) 
        if (*c=='/') *c='\\';
    sprintf(command, "mkdir %s", in_path);
    if ((ret_val=system(command)>0)) {
      printf("Could not create stimuli directory for input file!\n\n");
      return ret_val; 
    }
  }

  // Create result directory under the path specified. Optionally, if directory exists, clean it:
  sprintf(command, "cd %s", out_path);
  if ((ret_val=system(command)==0) && (clean>0)) {
    printf("Directory already exists. Removing all possible .bmp and .txt source files.\n");
    sprintf(command, "%s %s%c*.bmp", RM_COMMAND, out_path, SLASH); 
    system(command);
    sprintf(command, "%s %s%c*.txt", RM_COMMAND, out_path, SLASH); 
    system(command);
  }
  else {
    printf("Creating result directory under path specified.\n");
    sprintf(command, "mkdir %s", out_path);
    if ((ret_val=system(command)>0)) {
      printf("Could not create stimuli directory for input file!\n\n"); 
      return ret_val; 
    }
  }
  return(0);
}



int gen_stim( struct xilinx_ip_v_rgb2ycrcb_v7_1_generics *generics, 
              struct xilinx_ip_v_rgb2ycrcb_v7_1_inputs   *inputs,
              char *bmp_filename, char *output_dir, int NFRAMES, int transaction_id)
{
  char in_path[_MAX_PATH] = { 0 }; 
  char out_path[_MAX_PATH] = { 0 }; 
  char filename[_MAX_PATH] = { 0 }; 
  char command[_MAX_PATH] = { 0 }; 
  char in_filename[_MAX_PATH] = { 0 }; 
  char out_yuv_filename[_MAX_PATH] = { 0 }; 
  char out_txt_filename[_MAX_PATH] = { 0 }; 
  char inf_filename[_MAX_PATH] = { 0 }; 
  FILE* input_bmp=NULL; 
  FILE* input_txt=NULL;
  FILE* output_yuv=NULL;
  FILE* output_txt=NULL;
  int  ret_val = 2;     // Corresponds to memory allocation error
  int  numread=0;
//  char *c;
  int row, col;
  int bitshift;
  int frame, offsy, offsx, lsbs0, lsbs1, lsbs2;

  static struct rgb8_video_struct rgb8_in_video;
  static struct yuv8_video_struct yuv8_out_video;

  struct  xilinx_ip_v_rgb2ycrcb_v7_1_outputs  outputs;

  // Indicate that dynamic frame buffers are initially unallocated:
  rgb8_in_video.r = NULL;   
  yuv8_out_video.y = NULL;  
  outputs.video_out.data[0] = NULL;

  if (transaction_id==1) {  
    prep_dirs(output_dir, 1);
  }

  // Open input BMP file
  if ( (input_bmp = fopen(bmp_filename, "rb" )) == NULL ) { printf( "Could not open input bmp file %s\n",bmp_filename); return(4); }
  else                                                    { printf( "Reading input BMP file %s!\n",bmp_filename); }
  	
  // Read BMP file contents into the input frame buffer:
  if (read_bmp(input_bmp, &rgb8_in_video)>0) { ret_val=64; goto core_cleanup; }

  rgb8_in_video.mode = FORMAT_RGB;

  inputs->video_in.rows  = inputs->ACTIVE_ROWS;
  inputs->video_in.cols  = inputs->ACTIVE_COLS;
  inputs->video_in.frames = NFRAMES;
  inputs->video_in.mode = rgb8_in_video.mode;
  inputs->video_in.bits_per_component = generics->COEF_IN.IWIDTH;
  inputs->video_in.data[0] = NULL;
  inputs->video_in.data[1] = NULL;
  inputs->video_in.data[2] = NULL;
  if(alloc_video_buff(&inputs->video_in) > 0) goto core_cleanup;

  bitshift = generics->COEF_IN.IWIDTH-8;
  for (frame=0; frame<NFRAMES; frame++) {
    offsy=(RAND_ORIG) ? rand() : 0;   // Slice out a video_in.rows by video_in.cols rectangle from the input image
    offsx=(RAND_ORIG) ? rand() : 0;   // The top left corner location is randomized. The actual image created is cropped from an infinite plane tiled with the input bmp
    for (row=0; row<inputs->video_in.rows; row++) {
      for (col=0; col<inputs->video_in.cols; col++) {
        lsbs0 = ((row + col + 0) & ((1<<bitshift)-1));
        lsbs1 = ((row + col + 1) & ((1<<bitshift)-1));
        lsbs2 = ((row + col + 2) & ((1<<bitshift)-1));
        inputs->video_in.data[0][frame][row][col] = (rgb8_in_video.r[0][(row+offsy) % rgb8_in_video.rows][(col+offsx) % rgb8_in_video.cols] << bitshift) + lsbs0;
        inputs->video_in.data[1][frame][row][col] = (rgb8_in_video.g[0][(row+offsy) % rgb8_in_video.rows][(col+offsx) % rgb8_in_video.cols] << bitshift) + lsbs1;
        inputs->video_in.data[2][frame][row][col] = (rgb8_in_video.b[0][(row+offsy) % rgb8_in_video.rows][(col+offsx) % rgb8_in_video.cols] << bitshift) + lsbs2;
      }
    }
  }

  // write stimuli data to txt file
  printf("Writing stimuli txt file for the HDL test bench.\n");
  sprintf(in_path, "%s%cstimuli", output_dir, SLASH);
  sprintf(filename, "%s%cstimuli_%d.txt", in_path, SLASH, transaction_id);   
  if ( (input_txt = fopen(filename, "wb")) == NULL ) { printf( "Could not open input txt file: %s\n", filename ); ret_val = 16; goto core_cleanup; }
  if (WriteVideoTxtFile(input_txt, &(inputs->video_in), -1, 0, 0)>0) { ret_val=128; goto core_cleanup; }
  fflush(input_txt);

  //  Execute rgb2ycrcb Model 
  printf("Running rgb2ycrcb c_model\n");
  ret_val = xilinx_ip_v_rgb2ycrcb_v7_1_bitacc_simulate( generics, inputs, &outputs );
  if (ret_val > 0) goto core_cleanup;

  // write result video to txt file
  printf("Writing golden txt file for the HDL test bench.\n");
  sprintf(out_path, "%s%cexpected", output_dir, SLASH);
  sprintf(filename, "%s%cgolden_%d.txt", out_path, SLASH, transaction_id);   
  if ( (output_txt = fopen(filename, "w+b")) == NULL ) { printf( "Could not open output txt file: %s\n", filename ); ret_val = 32; goto core_cleanup; }
  if (WriteVideoTxtFile(output_txt, &(outputs.video_out), -1, 0, 0)>0) { ret_val=64; goto core_cleanup; }
  fflush(output_txt);

  // copied resulting video to yuv8_video:
  yuv8_out_video.frames  = inputs->video_in.frames;
  yuv8_out_video.rows    = inputs->video_in.rows;
  yuv8_out_video.cols    = inputs->video_in.cols;
  if ((copy_video_to_yuv8(&(outputs.video_out), &yuv8_out_video ))>0) goto core_cleanup;

  //  Open output yuv file and write results for visual verification
  printf("Writing result YUV file.\n");
  sprintf(out_yuv_filename, "%s%crgb2ycrcb_result_%d.yuv", out_path, SLASH, transaction_id);   
  if ((output_yuv = fopen(out_yuv_filename, "wb")) == NULL ) { printf( "Could not open output YUV file: %s\n", out_yuv_filename ); ret_val = 8; goto core_cleanup; }
  if (write_yuv8(output_yuv, &yuv8_out_video)>0) { ret_val=128; goto core_cleanup; }
  fflush(output_yuv);

  ret_val = 0;

  core_cleanup:
  printf("Closing Files.\n");
  if(input_bmp != NULL) fclose(input_bmp);
  if(input_txt != NULL) fclose(input_txt);
  if(output_txt != NULL) fclose(output_txt);
  if(output_yuv != NULL) fclose(output_yuv);
  printf("Freeing data structures...");
  if (rgb8_in_video.r>0)   free_rgb_frame_buff((struct rgb8_video_struct*) &rgb8_in_video);
  if (inputs->video_in.data[0]>0)  free_video_buff( &inputs->video_in);
  if (outputs.video_out.data[0]>0) free_video_buff( &outputs.video_out );
  if (yuv8_out_video.y>0)  free_yuv_frame_buff((struct yuv_video_struct*) &yuv8_out_video);
  printf("done.\n");
  return ret_val;
}
