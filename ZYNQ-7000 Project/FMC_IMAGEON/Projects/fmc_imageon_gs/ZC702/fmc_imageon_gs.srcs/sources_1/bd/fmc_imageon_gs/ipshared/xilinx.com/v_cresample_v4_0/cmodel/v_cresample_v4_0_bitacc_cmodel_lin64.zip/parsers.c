//-----------------------------------------------------------------------------
//  (c) Copyright 2011 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-----------------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "yuv_utils.h"
#include "parsers.h"

int is_alpha(char c)
{
  return( ((c>='a') && (c<='z')) ||
          ((c>='A') && (c<='Z')) ||
          ((c>='0') && (c<='9')) ||
          (c=='_') || (c=='.') || (c=='-'));
}

// This function compares two strings, ignoring case, returning TRUE if they are equal
int equal_strings(const char *a, const char *b)
{
  int len;
  char a2[256];
  char b2[256];
  int i;
  
  len = (int) strlen(a);

  // Create upper-case versions of both strings
  for (i=0; i<len; i++)
    {
      a2[i] = ((a[i]>='a') && (a[i]<='z')) ? (a[i]+'A'-'a') : a[i];
      b2[i] = ((b[i]>='a') && (b[i]<='z')) ? (b[i]+'A'-'a') : b[i];
    }
  a2[len]=0;
  b2[len]=0;
  // Compare the upper-case versions of the strings
  return(strcmp(a2,b2)==0);
}

// This function assigns an XCO variable, CFG parameter, or generic to a C model variable
int assign_xco_var(char *var_name, char* var_value, struct XCO_VARIABLES* xco_variables)
{
  // XCO file parameters

 if (equal_strings(var_name,"INTERLACED")) {
    if (strcmp(var_value, "true")==0) xco_variables->INTERLACED = 1; else 
                                      xco_variables->INTERLACED = 0; }
 if (equal_strings(var_name,"CHROMA_PARITY")) {
    if (strcmp(var_value, "odd")==0) xco_variables->CHROMA_PARITY = 1; else 
                                      xco_variables->CHROMA_PARITY = 0; }
 if (equal_strings(var_name,"FIELD_PARITY")) {
    if (strcmp(var_value, "odd")==0) xco_variables->FIELD_PARITY = 1; else 
                                      xco_variables->FIELD_PARITY = 0; }

  if (equal_strings(var_name,"S_AXIS_VIDEO_FORMAT"))		sscanf( var_value,"%d",  &(xco_variables->S_AXIS_VIDEO_FORMAT));
  if (equal_strings(var_name,"M_AXIS_VIDEO_FORMAT"))		sscanf( var_value,"%d",  &(xco_variables->M_AXIS_VIDEO_FORMAT));
  if (equal_strings(var_name,"NUM_H_TAPS"))					sscanf( var_value,"%d",  &(xco_variables->NUM_H_TAPS));
  if (equal_strings(var_name,"NUM_V_TAPS"))					sscanf( var_value,"%d",  &(xco_variables->NUM_V_TAPS));
  if (equal_strings(var_name,"CONVERT_TYPE"))				sscanf( var_value,"%d",  &(xco_variables->CONVERT_TYPE));
  if (equal_strings(var_name,"S_AXIS_VIDEO_DATA_WIDTH"))	sscanf( var_value,"%d",  &(xco_variables->S_AXIS_VIDEO_DATA_WIDTH));
  if (equal_strings(var_name,"ACTIVE_COLS"))				sscanf( var_value,"%d",  &(xco_variables->ACTIVE_COLS));
  if (equal_strings(var_name,"ACTIVE_ROWS"))				sscanf( var_value,"%d",  &(xco_variables->ACTIVE_ROWS));
  return(0);
}

// This function assigns an XCO variable, CFG parameter, or generic to a C model variable
int assign_cfg_var(char *var_name, char* var_value, struct CFG_VARIABLES* cfg_variables)
{
  // CFG file parameters
  if (equal_strings(var_name,"INPUT_FILE_NAME"))            sscanf( var_value,"%s",  cfg_variables->input_file_name);
  if (equal_strings(var_name,"OUTPUT_FILE_NAME"))           sscanf( var_value,"%s",  cfg_variables->output_file_name);
  if (equal_strings(var_name,"NUMBER_OF_FRAMES"))           sscanf( var_value,"%d",  &(cfg_variables->number_of_frames));
  if (equal_strings(var_name,"NUMBER_OF_ROWS"))             sscanf( var_value,"%d",  &(cfg_variables->number_of_rows));
  if (equal_strings(var_name,"NUMBER_OF_COLS"))             sscanf( var_value,"%d",  &(cfg_variables->number_of_cols));

  if (equal_strings(var_name,"COEF00_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[0]));   
  if (equal_strings(var_name,"COEF01_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[1]));   
  if (equal_strings(var_name,"COEF02_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[2]));   
  if (equal_strings(var_name,"COEF03_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[3]));   
  if (equal_strings(var_name,"COEF04_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[4]));   
  if (equal_strings(var_name,"COEF05_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[5]));   
  if (equal_strings(var_name,"COEF06_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[6]));   
  if (equal_strings(var_name,"COEF07_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[7]));   
  if (equal_strings(var_name,"COEF08_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[8]));   
  if (equal_strings(var_name,"COEF09_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[9]));   
  if (equal_strings(var_name,"COEF10_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[10]));  
  if (equal_strings(var_name,"COEF11_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[11]));  
  if (equal_strings(var_name,"COEF12_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[12]));   
  if (equal_strings(var_name,"COEF13_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[13]));   
  if (equal_strings(var_name,"COEF14_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[14]));   
  if (equal_strings(var_name,"COEF15_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[15]));   
  if (equal_strings(var_name,"COEF16_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[16]));   
  if (equal_strings(var_name,"COEF17_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[17]));   
  if (equal_strings(var_name,"COEF18_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[18]));   
  if (equal_strings(var_name,"COEF19_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[19]));   
  if (equal_strings(var_name,"COEF20_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[20]));   
  if (equal_strings(var_name,"COEF21_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[21]));   
  if (equal_strings(var_name,"COEF22_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[22]));  
  if (equal_strings(var_name,"COEF23_HPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase0[23]));  

  if (equal_strings(var_name,"COEF00_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[0]));   
  if (equal_strings(var_name,"COEF01_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[1]));   
  if (equal_strings(var_name,"COEF02_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[2]));   
  if (equal_strings(var_name,"COEF03_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[3]));   
  if (equal_strings(var_name,"COEF04_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[4]));   
  if (equal_strings(var_name,"COEF05_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[5]));   
  if (equal_strings(var_name,"COEF06_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[6]));   
  if (equal_strings(var_name,"COEF07_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[7]));   
  if (equal_strings(var_name,"COEF08_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[8]));   
  if (equal_strings(var_name,"COEF09_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[9]));   
  if (equal_strings(var_name,"COEF10_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[10]));  
  if (equal_strings(var_name,"COEF11_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[11]));  
  if (equal_strings(var_name,"COEF12_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[12]));   
  if (equal_strings(var_name,"COEF13_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[13]));   
  if (equal_strings(var_name,"COEF14_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[14]));   
  if (equal_strings(var_name,"COEF15_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[15]));   
  if (equal_strings(var_name,"COEF16_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[16]));   
  if (equal_strings(var_name,"COEF17_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[17]));   
  if (equal_strings(var_name,"COEF18_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[18]));   
  if (equal_strings(var_name,"COEF19_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[19]));   
  if (equal_strings(var_name,"COEF20_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[20]));   
  if (equal_strings(var_name,"COEF21_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[21]));   
  if (equal_strings(var_name,"COEF22_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[22]));  
  if (equal_strings(var_name,"COEF23_HPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_hphase1[23]));  

  if (equal_strings(var_name,"COEF00_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[0]));   
  if (equal_strings(var_name,"COEF01_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[1]));   
  if (equal_strings(var_name,"COEF02_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[2]));   
  if (equal_strings(var_name,"COEF03_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[3]));   
  if (equal_strings(var_name,"COEF04_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[4]));   
  if (equal_strings(var_name,"COEF05_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[5]));   
  if (equal_strings(var_name,"COEF06_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[6]));   
  if (equal_strings(var_name,"COEF07_VPHASE0"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase0[7]));   

  if (equal_strings(var_name,"COEF00_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[0]));   
  if (equal_strings(var_name,"COEF01_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[1]));   
  if (equal_strings(var_name,"COEF02_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[2]));   
  if (equal_strings(var_name,"COEF03_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[3]));   
  if (equal_strings(var_name,"COEF04_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[4]));   
  if (equal_strings(var_name,"COEF05_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[5]));   
  if (equal_strings(var_name,"COEF06_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[6]));   
  if (equal_strings(var_name,"COEF07_VPHASE1"))             sscanf( var_value,"%f",  &(cfg_variables->coef_vphase1[7]));

  return(0);
}


// This function reads the contents of the XCO file
int read_XCO(char *path_and_name, struct XCO_VARIABLES *xco_variables)
{
  char str[256];
  char var_name[256];
  char var_value[256];
  int i=0, j=0;
  int c;
  FILE *xco_file;

  if ((xco_file = fopen(path_and_name, "r")) == NULL)
    {
      printf("Cannot open %s!\n", path_and_name);
      return(280);
    }
  //printf("Opening XCO file for parameters: %s \n", path_and_name);

  // read the XCO file line-by-line
  while (!feof(xco_file ))
    {
      // go through the initial spaces and tabs
      while ((((c=fgetc(xco_file)) == ' ') || (c=='\t')) && (c!=EOF) && (c!=10))
        if (c=='#') // if line starts with comment char, skip it
          while (((c=fgetc(xco_file)) !=EOF) && (c!=10));
      if ((c!=EOF) && (c!=10) && (c!='#'))
        {
          // extract the command
          i=0; str[i++]=c;
          while (is_alpha(c=fgetc(xco_file))) str[i++]=c;
          str[i]=0;

          // check if the line is a CSET statement.
          if (equal_strings(str, "CSET"))
            {

              // go through the initial spaces and tabs
              while ((((c=fgetc(xco_file)) == ' ') || (c=='\t')) && (c!=EOF) && (c!=10)) i++;
              if ((c==EOF) || (c==10))
                {
                  printf("Unexpected end of XCO file: %s!\n", path_and_name);
                  printf("Quitting! \n");
                  return(290);
                }

              // Extract the variable name;
              j=0; var_name[j++]=c;
              while (is_alpha(c=fgetc(xco_file))) var_name[j++]=c;
              var_name[j]=0;
              if ((c==EOF) || (c==10))
                {
                  printf("Unexpected end of XCO file: %s!\n", path_and_name);
                  printf("Quitting! \n");
                  return(290);
                }

              // go through spaces, tabs and '=' signs
              while ((((c=fgetc(xco_file)) == ' ') || (c=='\t') || (c=='=')) && c!=EOF) i++;
              if ((c==EOF) || (c==10))
                {
                  printf("Unexpected end of XCO file: %s!\n", path_and_name);
                  printf("Quitting! \n");
                  return(290);
                }

              // Extract the variable value;
              j=0; var_value[j++]=c;
              while (is_alpha(c=fgetc(xco_file))) { var_value[j++]=c; }
              var_value[j]=0;
              if (assign_xco_var(var_name, var_value, xco_variables))
                {
                  printf("Unknown XCO variable %s was found!\n", var_name);
                  printf("Found in xco file: %s!\n", path_and_name);
                }
            }
        }
      // read through the end of the line
      while ((c != EOF) && (c!='\n')) c=fgetc(xco_file);
    }
  fclose(xco_file);
  return(0);
}

// This function reads the contents of the cfg file
// and also creates a copy of the file
int read_CFG(char *path_and_name, struct CFG_VARIABLES* cfg_variables)
{
  char var_name[256];
  char var_value[256];
  //char cfg_contents[256][256];
  int i=0, j=0, l=0, m=0;
  int c;
  FILE *cfg_file;
  fpos_t start_pos;

  if ((cfg_file = fopen(path_and_name, "r")) == NULL)
    {
      printf("Cannot open file %s!\n", path_and_name);
      return(280);
    }
  printf("Opening CFG file for simulation guides: %s \n", path_and_name);
  fgetpos(cfg_file, &start_pos);  // Record position at start of file

  // read the CFG file line-by-line
  while (!feof(cfg_file ))
    {
      // go through the initial spaces and tabs
      while ((((c=fgetc(cfg_file)) == ' ') || (c=='\t')) && (c!=EOF) && (c!=10)) i++;
      if (c=='#') // if line starts with comment char, skip it
        while (((c=fgetc(cfg_file)) !=EOF) && (c!=10));
      if ((c!=EOF) && (c!=10) && (c!='#'))
        {

          // Extract the variable name;
          j=0; var_name[j++]=c;
          while (is_alpha(c=fgetc(cfg_file)))  var_name[j++]=c;
          var_name[j]=0;
          if (strcmp(var_name, "CSET")==0) {
            var_name[j=0]=c;
            while (is_alpha(c=fgetc(cfg_file)))  var_name[j++]=c;
            var_name[j]=0; }
          if ((c==EOF) || (c==10))
            {
              printf("Unexpected end of CFG file: %s!\n", path_and_name);
              printf("Quitting! \n");
              return(290);
            }

          // go through spaces, tabs and '=' signs
          while ((((c=fgetc(cfg_file)) == ' ') || (c=='\t') || (c=='=')) && c!=EOF) i++;
          if ((c==EOF) || (c==10))
            {
              printf("Unexpected end of CFG file: %s!\n", path_and_name);
              printf("Quitting! \n");
              return(290);
            }

          // Extract the variable value;
          j = 0; 
	  var_value[j++] = c;
          while (is_alpha(c=fgetc(cfg_file)))
	    {
	      var_value[j++] = c;
	    }
          var_value[j] = 0;
          if (assign_cfg_var(var_name, var_value, cfg_variables))
            {
              printf("Unknown CFG variable %s was found!\n", var_name);
              printf("Found in file: %s!\n", path_and_name);
            }

          // read till end of line
          while ((c != EOF) && (c!='\n')) c=fgetc(cfg_file);
        }
    }
  return(0);
}
