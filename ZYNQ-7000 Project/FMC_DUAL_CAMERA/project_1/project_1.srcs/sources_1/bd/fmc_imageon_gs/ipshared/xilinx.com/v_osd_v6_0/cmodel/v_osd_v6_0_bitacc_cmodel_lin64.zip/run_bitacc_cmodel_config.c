//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 5.01a
//  \   \        Filename: $RCSfile: run_bitacc_cmodel_config.c,v $
//  /   /        Date Last Modified: $Date: 2011-03-03 09:28:06 -0700 (Thu, 03 Mar 2011) $
// /___/   /\    Date Created: 2009
// \   \  /  \
//  \___\/\___\
//
// Device  : All
// Library : v_osd_v6_0
// Purpose : Configurable Smoke test program for bit accurate C model
//-----------------------------------------------------------------------------
//  (c) Copyright 2011-2012 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#ifdef NT
  #include <direct.h>
#else
  #include <sys/stat.h>
#endif

#include "rgb_utils.h"
#include "bmp_utils.h"
#include "yuv_utils.h"
#include "video_utils.h"
#include "v_osd_v6_0_bitacc_cmodel.h"
#define CREATE_STIMULUS 1
//using namespace std;

int main(int argc, char* argv[])
{
  int i, j, layer, frame, string_offset, font_size, ret_val;
  int max_x = 0, max_y = 0;
  int screen_max_x = 0, screen_max_y = 0;
  int ok, setup_mode = 1;
  int end_text = 0;
  int end_font = 0;
  int end_clut = 0;
  int end_ins  = 0;
  int ins_comment = 0;
  uint16 *clut = NULL;
  int *font_ram = NULL;
  char * text_ram = NULL;
  char ins_string[8]; // BOX, TEXT, BOXTEXT
  char ins_val[20]; // For integers in dec or hex
  struct graphics_cfg_struct *gfx_cfg_ptr = NULL; 
  static struct graphics_list * gfx_list = NULL;
  static struct graphics_list * gfx_list_last = NULL;
  struct layer_cfg_struct * layer_cfg_ptr = NULL;
  struct layer_cfg_struct *layer_cfg_ptr_array[OSD_MAX_LAYERS];

  static struct rgb8_video_struct rgb8_layer_video[OSD_MAX_LAYERS];
  static struct yuv_video_struct yuv_layer_video[OSD_MAX_LAYERS];
  static struct yuv8_video_struct yuv_out_video444;
  static struct rgb8_video_struct rgb8_out_video;
  struct yuv8_video_struct yuv8_tmp_video;
  struct frame_cfg_struct * frame_cfg_ptr;

  char * osd_files[5*OSD_MAX_LAYERS+1];
  
  FILE* output_fid     = NULL;
  FILE* clut_fid       = NULL;
  FILE* text_fid       = NULL;
  FILE* font_fid       = NULL;
  FILE* ins_fid        = NULL;
  FILE* input_fid[OSD_MAX_LAYERS];

#ifdef CREATE_STIMULUS
  char osd_expected_filename[132]; 
  char * osd_expected_file = "expected/video_out.txt";
  char * osd_regin_file = "stimuli/reg_in.txt";

// expected Files
  FILE* osd_expected_fid   = NULL;
  FILE* osd_regin_fid   = NULL;

  struct  video_struct video_stimulus_out;
  int layer_enable, g_alpha_en;
#endif

  // Use default generics for this smoke test
  struct xilinx_ip_v_osd_v6_0_generics generics;


  // Create structure for inputs and input data arrays
  struct xilinx_ip_v_osd_v6_0_inputs inputs;

  // Create structure for outputs and output data arrays
  struct xilinx_ip_v_osd_v6_0_outputs outputs;

  // Create state
  struct xilinx_ip_v_osd_v6_0_state* state;



  generics = xilinx_ip_v_osd_v6_0_get_default_generics();
  // Declare any arrays in the inputs structure and write pointers to them into the inputs structure
  inputs.color_space = 3; //YUV 4:4:4 - FORMAT_C444
  inputs.num_frames = 1;

  // Initialize input file array
  for(i=0; i <= 5*OSD_MAX_LAYERS; i++)
  {
    osd_files[i] = NULL;
  }

  // Parse Config File and Command Line Arguments
  if(osd_parse_args(argc, argv, &generics, &inputs, osd_files, &setup_mode))
  {
          return(4096);
  }
  
  if(inputs.color_space == FORMAT_RGB)
  {
        printf("WARNING: Setting number of frames to 1 for RGB.\n");
        inputs.num_frames = 1;
  }


#ifdef CREATE_STIMULUS
  if(setup_mode & 0x01) // If generate Stimulus bit set
  {
#ifdef NT
        mkdir("stimuli");
#else
     mkdir("stimuli", 0755);
#endif
        if (OSD_DEBUG) printf("Opening Simulation Reg-In File '%s'...\n", osd_regin_file);
        if ( (osd_regin_fid = fopen(osd_regin_file, "w")) == NULL ) 
        {
          printf( "ERROR: Could not open reg file '%s'\n", osd_regin_file); return(8); 
        }
        // initialize pointers.
        frame_cfg_ptr = inputs.frame_cfg;
        for(j=0; j<generics.C_NUM_LAYERS; j++)
        {
          layer_cfg_ptr_array[j] = inputs.layer_cfg[j];
        }
        //write out one line for every frame
        for(i=0; i < inputs.num_frames; i++)
        {
                  // 55 register values
                     fprintf(osd_regin_fid, "%d %d %d %d %d ", 
                                       frame_cfg_ptr->bg_color[0], 
                                       frame_cfg_ptr->bg_color[1], 
                                       frame_cfg_ptr->bg_color[2], 
                                       frame_cfg_ptr->x_size,
                                       frame_cfg_ptr->y_size
                                       );
                     if(frame_cfg_ptr->next != NULL)
                     {
                       frame_cfg_ptr = frame_cfg_ptr->next;
                     }
                     //layer_enable
                     layer_enable = 0;
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                layer_enable |= (layer_cfg_ptr_array[j]->enable & 1 )<< j;
                        }
                     }
                     fprintf(osd_regin_fid, "%d ", layer_enable);

                     //layer_enable
                     g_alpha_en = 0;
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                g_alpha_en |= (layer_cfg_ptr_array[j]->g_alpha_en & 1 )<< j;
                        }
                     }
                     fprintf(osd_regin_fid, "%d ", g_alpha_en);


                     //Priority
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                fprintf(osd_regin_fid, "%d ", layer_cfg_ptr_array[j]->priority);
                        }
                        else
                        {
                                fprintf(osd_regin_fid, "%d ", 0);
                        }
                     }
                     // Alpha
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                fprintf(osd_regin_fid, "%d ", layer_cfg_ptr_array[j]->alpha);
                        }
                        else
                        {
                                fprintf(osd_regin_fid, "%d ", 0);
                        }
                     }
                     // X Position
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                fprintf(osd_regin_fid, "%d ", layer_cfg_ptr_array[j]->x_pos);
                        }
                        else
                        {
                                fprintf(osd_regin_fid, "%d ", 0);
                        }
                     }
                     // Y Position
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                fprintf(osd_regin_fid, "%d ", layer_cfg_ptr_array[j]->y_pos);
                        }
                        else
                        {
                                fprintf(osd_regin_fid, "%d ", 0);
                        }
                     }
                     // X size
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                fprintf(osd_regin_fid, "%d ", layer_cfg_ptr_array[j]->x_size);
                        }
                        else
                        {
                                fprintf(osd_regin_fid, "%d ", 0);
                        }
                     }
                     // Y size
                     for(j=0; j<OSD_MAX_LAYERS; j++)
                     {
                        if(j<generics.C_NUM_LAYERS) 
                        {
                                fprintf(osd_regin_fid, "%d ", layer_cfg_ptr_array[j]->y_size);
                        }
                        else
                        {
                                fprintf(osd_regin_fid, "%d ", 0);
                        }
                     }
                     // EOL
                     fprintf(osd_regin_fid, "\n");

                     // Increment each layer config struct point to the next frame config
                     for(j=0; j<generics.C_NUM_LAYERS; j++)
                     {
                       if(layer_cfg_ptr_array[j]->next != NULL)
                       {
                         layer_cfg_ptr_array[j] = layer_cfg_ptr_array[j]->next;
                       }
                     }


                  }
                  
      fclose(osd_regin_fid);

  }
  printf("Register Input Stimulus Complete.\n");
#endif  
  ///////////////////////////////////////////////////////////////////////////
  // Setup Graphics Layer Configurations
  ///////////////////////////////////////////////////////////////////////////
  for(layer=0; layer< generics.C_NUM_LAYERS; layer++)
  {
    if(generics.C_LAYER_TYPE[layer] == 1) // Graphics Controller
    {
      // initialize for each layer every frame

      printf("Opening Graphics Instruction File '%s'...\n", osd_files[layer*5 + 1]);
      if( (ins_fid = fopen(osd_files[layer*5 + 1],"r")) == NULL)
      {
              printf("ERROR: Cannot open Graphics Instruction File '%s'...\n", osd_files[layer*5 + 1]);
              return(8);
      }
      printf("Opening Color Pallet File '%s'...\n", osd_files[layer*5 + 2]);
      if( (clut_fid = fopen(osd_files[layer*5 + 2],"r")) == NULL)
      {
              printf("ERROR: Cannot open Color Pallet File '%s'...\n", osd_files[layer*5 + 2]);
              return(8);
      }
      printf("Opening Font File '%s'...\n", osd_files[layer*5 + 3]);
      if( (font_fid = fopen(osd_files[layer*5 + 3],"r")) == NULL)
      {
              printf("ERROR: Cannot open Font File '%s'...\n", osd_files[layer*5 + 3]);
              return(8);
      }
      printf("Opening Text File '%s'...\n", osd_files[layer*5 + 4]);
      if( (text_fid = fopen(osd_files[layer*5 + 4],"r")) == NULL)
      {
              printf("ERROR: Cannot open Text File '%s'...\n", osd_files[layer*5 + 4]);
              return(8);
      }
      gfx_cfg_ptr = NULL;
      end_text = 0;
      end_font = 0;
      end_clut = 0;
      end_ins  = 0;

      // Frame loop
      for(frame=0;frame< inputs.num_frames; frame++)
      {

        if(gfx_cfg_ptr == NULL)
        {
          gfx_cfg_ptr = (struct graphics_cfg_struct *) calloc(1, sizeof(struct graphics_cfg_struct));
          gfx_cfg_ptr->next = NULL;
          inputs.gfx_cfg[layer] = gfx_cfg_ptr; // point to first struct in linked list
        }
        else
        {
          gfx_cfg_ptr->next = (struct graphics_cfg_struct *) calloc(1, sizeof(struct graphics_cfg_struct));
          gfx_cfg_ptr = gfx_cfg_ptr->next;
          gfx_cfg_ptr->next = NULL;
        }



        gfx_cfg_ptr->layer_num          = layer;




        //////////////////////////////////////////////////////////////////
        // Allocate memory block for text ram
        //////////////////////////////////////////////////////////////////
        if(end_text == 0)
        {
          text_ram = (char *) calloc(generics.C_LAYER_TEXT_NUM_STRINGS[layer] * generics.C_LAYER_TEXT_MAX_STRING_LENGTH[layer] , sizeof(char));
        }
        gfx_cfg_ptr->text_ram = text_ram;

        //load from file
        printf("Loading Strings for layer %d.\n", layer);
        if(end_text == 0)
        {
          for(i = 0; i < generics.C_LAYER_TEXT_NUM_STRINGS[layer]; i++)
          {
            string_offset = i *  generics.C_LAYER_TEXT_MAX_STRING_LENGTH[layer];
            if(fgets(&text_ram[string_offset],generics.C_LAYER_TEXT_MAX_STRING_LENGTH[layer],text_fid ) == NULL)
            {
                  printf("End String File.\n");
                  end_text = 1;
            }
            j=0;
            while((text_ram[string_offset + j] != '\n') && (text_ram[string_offset + j] != '\r'))
            {
                    j++;
            }
            text_ram[string_offset + j] = '\0';
            printf("String: '%s' \n", &text_ram[string_offset] );
          }
        }
           


        //////////////////////////////////////////////////////////////////
        // Allocate memory block for font ram
        //////////////////////////////////////////////////////////////////
        font_size =  (generics.C_LAYER_FONT_NUM_CHARS[layer] - generics.C_LAYER_FONT_ASCII_OFFSET[layer]) * generics.C_LAYER_FONT_HEIGHT[layer];
                            // * generics.C_LAYER_FONT_WIDTH[layer];
        if(end_font == 0)
        {

          font_ram = (int*) calloc(  font_size // * generics.C_LAYER_FONT_BPP[layer]
                            , sizeof(int));

        }
        gfx_cfg_ptr->font_ram = font_ram;

       
        printf("Loading font for layer %d.\n", layer);
        //load from file
        if(end_font == 0)
        {
          for(i = 0; i < font_size; i ++)
          {
            if(fscanf(font_fid , "%s", ins_val) != 1)
            {
                  end_font = 1;
            }
            else
            {
              if(!(strncmp(ins_val,"0x",2)))
              {
                sscanf(&ins_val[2], "%x", &font_ram[i]);
              }
              else
              {
                sscanf(ins_val, "%d", &font_ram[i]);
              }
            }
            //printf("FONT: %d.\n", font_ram[i]);

          }
        }
        //////////////////////////////////////////////////////////////////
        // Allocate memory block for clut ram
        //////////////////////////////////////////////////////////////////
        if(end_clut == 0)
        {

          clut = (uint16*) calloc(  generics.C_LAYER_CLUT_SIZE[layer] * 4
                            , sizeof(uint16));

        }
        gfx_cfg_ptr->clut = clut;

       
        //load from file
        printf("Loading color for layer %d.\n", layer);
        if(end_clut == 0)
        {
          for(i = 0; i < generics.C_LAYER_CLUT_SIZE[layer] * 4 ; i ++)
          {
            if(fscanf(clut_fid , "%s", ins_val) != 1)
            {
                  end_clut = 1;
            }
            else
            {
              if(!(strncmp(ins_val,"0x",2)))
              {
                sscanf(&ins_val[2], "%x", &clut[i]);
              }
              else
              {
                sscanf(ins_val, "%d", &clut[i]);
              }
            }

            //printf("CLUT: %d.\n", clut[i]);
          }
        }


        //////////////////////////////////////////////////////////////////
        // Allocate memory block for instruction ram
        //////////////////////////////////////////////////////////////////

        if(end_ins == 1)
        {
          gfx_cfg_ptr->graph_instruction = gfx_list_last;
        }
        gfx_list = NULL;

        //load from file
        //while(fscanf(ins_fid , "%s", ins_string) == 1)
        ins_string[0] = '\0';
        printf("Loading instructions for layer %d.\n", layer);
        while((strncmp(ins_string,"END",3)) && (end_ins == 0))
        {
          if(fscanf(ins_fid , "%s", ins_string) == 1)
          {

            if(strncmp(ins_string,"END",3) && strncmp(ins_string,"#",1) && strncmp(ins_string,";",1)) // if not "END"
            {

                printf("Allocating memory for instruction...\n");
                if(gfx_list == NULL)
                {
                        gfx_list = (struct graphics_list *) calloc(1, sizeof(struct graphics_list));
                        gfx_cfg_ptr->graph_instruction = gfx_list;
                        gfx_list_last = gfx_list;

                }
                else
                {
                        gfx_list->next = (struct graphics_list *) calloc(1, sizeof(struct graphics_list));
                        gfx_list = gfx_list->next;

                }
                ins_comment = 0;
                if(!strncmp(ins_string,"BOXTEXT",8))
                {
                  gfx_list->opcode = OSD_INS_BOXTEXT;
                }
                else if(!strncmp(ins_string,"BOX",3))
                {
                  gfx_list->opcode = OSD_INS_BOX;
                }
                else if(!strncmp(ins_string,"TEXT",4))
                {
                  gfx_list->opcode = OSD_INS_TEXT;
                }
                //else
                //{
                //        end_ins == 1;
                //}
                printf("INS: %s.\n", ins_string); 
                ///////////////////////////////////////////////////////////////
                if((fscanf(ins_fid , "%s", ins_val) != 1))
                {
                        printf("ERROR: Incomplete Instruction '%s'.  Cannot set xstart.\n", ins_string);
                        return(1024);
                }
                if(!(strncmp(ins_val,"0x",2)))
                {
                  sscanf(&ins_val[2], "%x", &gfx_list->xstart);
                }
                else
                {
                  sscanf(ins_val, "%d", &gfx_list->xstart);
                }
                
                ///////////////////////////////////////////////////////////////
                if((fscanf(ins_fid , "%s", ins_val) != 1))
                {
                        printf("ERROR: Incomplete Instruction '%s'.  Cannot set xstop.\n", ins_string);
                        return(1024);
                }
                if(!(strncmp(ins_val,"0x",2)))
                {
                  sscanf(&ins_val[2], "%x", &gfx_list->xstop);
                }
                else
                {
                  sscanf(ins_val, "%d", &gfx_list->xstop);
                }

                ///////////////////////////////////////////////////////////////
                if((fscanf(ins_fid , "%s", ins_val) != 1))
                {
                        printf("ERROR: Incomplete Instruction '%s'.  Cannot set ystart.\n", ins_string);
                        return(1024);
                }
                if(!(strncmp(ins_val,"0x",2)))
                {
                  sscanf(&ins_val[2], "%x", &gfx_list->ystart);
                }
                else
                {
                  sscanf(ins_val, "%d", &gfx_list->ystart);
                }
                ///////////////////////////////////////////////////////////////
                if((fscanf(ins_fid , "%s", ins_val) != 1))
                {
                        printf("ERROR: Incomplete Instruction '%s'.  Cannot set ystop.\n", ins_string);
                        return(1024);
                }
                if(!(strncmp(ins_val,"0x",2)))
                {
                  sscanf(&ins_val[2], "%x", &gfx_list->ystop);
                }
                else
                {
                  sscanf(ins_val, "%d", &gfx_list->ystop);
                }

                ///////////////////////////////////////////////////////////////
                if((fscanf(ins_fid , "%s", ins_val) != 1))
                {
                        printf("ERROR: Incomplete Instruction '%s'.  Cannot set color index.\n", ins_string);
                        return(1024);
                }
                if(!(strncmp(ins_val,"0x",2)))
                {
                  sscanf(&ins_val[2], "%x", &gfx_list->color_index);
                }
                else
                {
                  sscanf(ins_val, "%d", &gfx_list->color_index);
                }

                ///////////////////////////////////////////////////////////////
                if((fscanf(ins_fid , "%s", ins_val) != 1))
                {
                        printf("ERROR: Incomplete Instruction '%s'.  Cannot set text index.\n", ins_string);
                        return(1024);
                }
                if(!(strncmp(ins_val,"0x",2)))
                {
                  sscanf(&ins_val[2], "%x", &gfx_list->text_index);
                }
                else
                {
                  sscanf(ins_val, "%d", &gfx_list->text_index);
                }

                ///////////////////////////////////////////////////////////////
                if((fscanf(ins_fid , "%s", ins_val) != 1))
                {
                        printf("ERROR: Incomplete Instruction '%s'.  Cannot set Object Size.\n", ins_string);
                        return(1024);
                }
                if(!(strncmp(ins_val,"0x",2)))
                {
                  sscanf(&ins_val[2], "%x", &gfx_list->object_size);
                }
                else
                {
                  sscanf(ins_val, "%d", &gfx_list->object_size);
                }
                
                gfx_list->next = NULL;
            } // end if not "END"
            else
            {
                    fscanf(ins_fid, "%[^\n]", ins_string);
            }
          }
          else
          {
                  end_ins = 1;
          }

        }


      } // END For frame

      //close files
      fclose(font_fid );
      fclose(text_fid );
      fclose(clut_fid );
      fclose(ins_fid );

    } // END for layer
  }

  ////////////////////////////////////////////////////////////////////////
  // setup output max size
  ////////////////////////////////////////////////////////////////////////
  if(OSD_DEBUG) printf("Calculating Maximum Output Size...\n");
  screen_max_x = 0;
  screen_max_y = 0;
  frame_cfg_ptr = inputs.frame_cfg;
  while(frame_cfg_ptr != NULL)
  {
          if(frame_cfg_ptr->x_size > screen_max_x) screen_max_x = frame_cfg_ptr->x_size;
          if(frame_cfg_ptr->y_size > screen_max_y) screen_max_y = frame_cfg_ptr->y_size;
          frame_cfg_ptr = frame_cfg_ptr->next;
  }


  ////////////////////////////////////////////////////////////////////////
  // Configure Input Buffers
  ////////////////////////////////////////////////////////////////////////
  for(i=0; i < generics.C_NUM_LAYERS; i++)
  {
    if (OSD_DEBUG) printf("Calculating Maximum Layer Size for Layer %d...\n", i);
    max_x = 0;
    max_y = 0;
    layer_cfg_ptr = inputs.layer_cfg[i];
    frame_cfg_ptr = inputs.frame_cfg;
    while(layer_cfg_ptr != NULL)
    {
            if(layer_cfg_ptr->x_size > max_x) max_x = layer_cfg_ptr->x_size;
            if(layer_cfg_ptr->y_size > max_y) max_y = layer_cfg_ptr->y_size;
    
            if(max_x >  frame_cfg_ptr->x_size) max_x = frame_cfg_ptr->x_size;
            if(max_y >  frame_cfg_ptr->y_size) max_y = frame_cfg_ptr->y_size;

            layer_cfg_ptr = layer_cfg_ptr->next;
            frame_cfg_ptr = frame_cfg_ptr->next;
    }

    // Setup Layer i Video Buffer 
    if (OSD_DEBUG) printf("Setting up Layer %d Buffer\n", i);
    inputs.video_in[i].frames          = inputs.num_frames;
    inputs.video_in[i].rows            = max_y;
    inputs.video_in[i].cols            = max_x;
    if(inputs.layer_cfg[i]->chan_mode[0] == OSD_PREFILL_MODE)
    {
      // only FORMAT_C422, FORMAT_C444, FORMAT_RGB valid
      inputs.video_in[i].mode            = inputs.color_space; // Change with color_space config
    }
    else
    {
      if(inputs.color_space == FORMAT_C422) inputs.video_in[i].mode = FORMAT_C422_A;     
      if(inputs.color_space == FORMAT_C444) inputs.video_in[i].mode = FORMAT_C444_A;
      if(inputs.color_space == FORMAT_RGB)  inputs.video_in[i].mode = FORMAT_RGB_A;    
    }
    inputs.video_in[i].bits_per_component = generics.C_DATA_WIDTH;
    inputs.video_in[i].data[0]         = NULL; // Y
    inputs.video_in[i].data[1]         = NULL; // U
    inputs.video_in[i].data[2]         = NULL; // V
    inputs.video_in[i].data[3]         = NULL; // Alpha
  }


  ////////////////////////////////////////////////////////////////////////
  // Declare any arrays in the outputs structure and write pointers to them into the outputs structure
  //
  // Setup Output Video Buffer 
  ////////////////////////////////////////////////////////////////////////
  if (OSD_DEBUG) printf("Setting up Output Buffer\n");
  outputs.video_out.frames          = inputs.num_frames;
  outputs.video_out.rows            = screen_max_y; //inputs.frame_cfg->y_size;
  outputs.video_out.cols            = screen_max_x; //inputs.frame_cfg->x_size;
  // only FORMAT_C422, FORMAT_C444, FORMAT_RGB valid
  outputs.video_out.mode            = inputs.color_space;
  outputs.video_out.bits_per_component = generics.C_DATA_WIDTH;
  outputs.video_out.data[0]         = NULL;
  outputs.video_out.data[1]         = NULL;
  outputs.video_out.data[2]         = NULL;



  // Allocate and pre-fill buffers with layer data from file
  for(i=0; i < generics.C_NUM_LAYERS; i++)
  {
    if(inputs.layer_cfg[i]->chan_mode[0] == OSD_PREFILL_MODE)
    {
      input_fid[i] = NULL;

      if (OSD_DEBUG) printf("Opening Input File '%s'...\n", osd_files[5*i]);
      if ( (input_fid[i] = fopen(osd_files[5*i], "rb")) == NULL ) 
      {
        printf( "ERROR: Layer %d - Could not open input yuv file '%s'\n", i, osd_files[5*i] ); return(8); 
      }

      if(inputs.color_space == FORMAT_RGB)
      {
        //Setup YUV Input buffer for layer i
        rgb8_layer_video[i].frames          = inputs.num_frames;
        rgb8_layer_video[i].rows            = inputs.layer_cfg[i]->y_size;
        rgb8_layer_video[i].cols            = inputs.layer_cfg[i]->x_size;
        rgb8_layer_video[i].mode            = FORMAT_RGB;
        rgb8_layer_video[i].bits_per_component = generics.C_DATA_WIDTH;
        rgb8_layer_video[i].r               = NULL;
        rgb8_layer_video[i].g               = NULL;
        rgb8_layer_video[i].b               = NULL;


        // Allocate dynamic buffer for video:
        if(OSD_DEBUG) printf("Allocating RGB buffer for Layer %d...\n", i);
        if(alloc_rgb8_frame_buff(&rgb8_layer_video[i]) > 0) 
        {
          printf("ERROR: Cannot Allocate rgb Memory\n");
          free_rgb_frame_buff(&rgb8_layer_video[i]);
          return(128);
        }
  
        // Allocate dynamic buffer for video:
        if(alloc_video_buff(&inputs.video_in[i]) > 0) 
        {
          printf("ERROR: Cannot Allocate Video Memory\n");
          free_video_buff(&inputs.video_in[i]);
          return(128);
        }

          printf("Reading RGB Input.\n");
          // Read BMP file contents into the input frame buffer:
          if (read_bmp(input_fid[i], &rgb8_layer_video[i])>0) 
          { 
            printf( "ERROR: Could not read input yuv file '%s'\n", osd_files[5*i] ); 
                  return(64); 
          }

        //Copy data to input layer buffer
        printf("Copying RGB buffer to Video buffer.\n");
        copy_rgb8_to_video(&rgb8_layer_video[i], &inputs.video_in[i]);

      }
      else
      {
        //Setup YUV Input buffer for layer i
        yuv_layer_video[i].frames          = inputs.num_frames;
        yuv_layer_video[i].rows            = inputs.layer_cfg[i]->y_size;
        yuv_layer_video[i].cols            = inputs.layer_cfg[i]->x_size;
        yuv_layer_video[i].chroma_format   = inputs.color_space; //FORMAT_C444;
        yuv_layer_video[i].bits_per_component = generics.C_DATA_WIDTH;
        yuv_layer_video[i].y               = NULL;
        yuv_layer_video[i].u               = NULL;
        yuv_layer_video[i].v               = NULL;
  
        // Allocate dynamic buffer for video:
        if(OSD_DEBUG) printf("Allocating YUV buffer for Layer %d...\n", i);
        if(alloc_yuv_frame_buff(&yuv_layer_video[i]) > 0) 
        {
          printf("ERROR: Cannot Allocate YUV Memory\n");
          free_yuv_frame_buff((struct yuv_video_struct*)&yuv_layer_video[i]);
          return(128);
        }
  
        // Allocate dynamic buffer for video:
        if(alloc_video_buff(&inputs.video_in[i]) > 0) 
        {
          printf("ERROR: Cannot Allocate Video Memory\n");
          free_video_buff(&inputs.video_in[i]);
          return(128);
        }
  
  
#if 0
        if(inputs.color_space == FORMAT_C422)
        {
          //Setup YUV Input buffer for layer i
          yuv8_tmp_video.frames          = inputs.num_frames;
          yuv8_tmp_video.rows            = inputs.layer_cfg[i]->y_size;
          yuv8_tmp_video.cols            = inputs.layer_cfg[i]->x_size;
          yuv8_tmp_video.chroma_format   = FORMAT_C422;
          yuv8_tmp_video.bits_per_component = generics.C_DATA_WIDTH;
          yuv8_tmp_video.y               = NULL;
          yuv8_tmp_video.u               = NULL;
          yuv8_tmp_video.v               = NULL;
  
          // Allocate dynamic buffer for video:
          if(OSD_DEBUG) printf("Allocating YUV 422 buffer for Layer %d...\n", i);
          if(alloc_yuv8_frame_buff(&yuv8_tmp_video) > 0) 
          {
            printf("ERROR: Cannot Allocating Memory\n");
            free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_tmp_video);
            return(128);
          }
  
          printf("Reading YUV 422 Input.\n");
          // Read YUV file contents into the input frame buffer:
          if (read_yuv8(input_fid[i], &yuv8_tmp_video)>0) 
          { 
            printf( "ERROR: Could not read input yuv file '%s'\n", osd_files[5*i] ); 
                  return(64); 
          }
  
          printf("Converting YUV 422 to 444.\n");
          //translate 422 -> 444
          if (yuv8_422to444(&yuv8_tmp_video, &yuv8_layer_video[i])>0)
          {
            printf( "ERROR: Could not Convert 422 to 444.\n");
                  return(64); 
          }
          // Free tmp buffer
          free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_tmp_video);
  
  
        }
        else if(inputs.color_space == FORMAT_C420)
        {
                printf("Reading YUV 420 Input.\n");
          //Setup YUV Input buffer for layer i
          yuv8_tmp_video.frames          = inputs.num_frames;
          yuv8_tmp_video.rows            = inputs.layer_cfg[i]->y_size;
          yuv8_tmp_video.cols            = inputs.layer_cfg[i]->x_size;
          yuv8_tmp_video.chroma_format   = FORMAT_C420;
          yuv8_tmp_video.bits_per_component = generics.C_DATA_WIDTH;
          yuv8_tmp_video.y               = NULL;
          yuv8_tmp_video.u               = NULL;
          yuv8_tmp_video.v               = NULL;
  
  
          // Allocate dynamic buffer for video:
          if(OSD_DEBUG) printf("Allocating YUV 420 buffer for Layer %d...\n", i);
          if(alloc_yuv8_frame_buff(&yuv8_tmp_video) > 0) 
          {
            printf("ERROR: Cannot Allocating Memory\n");
            free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_tmp_video);
            return(128);
          }
  
          // Read YUV file contents into the input frame buffer:
          if (read_yuv8(input_fid[i], &yuv8_tmp_video)>0) 
          { 
            printf( "ERROR: Could not read input yuv file '%s'\n", osd_files[5*i] ); 
                  return(64); 
          }
  
          //traslate 420 -> 444
          yuv8_420to444(&yuv8_tmp_video, &yuv8_layer_video[i]);
          // Free tmp buffer
          free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_tmp_video);
  
  
        }
        else
        {
                printf("Reading YUV 444 Input.\n");
          // Read YUV file contents into the input frame buffer:
          if (read_yuv8(input_fid[i], &yuv8_layer_video[i])>0) 
          { 
            printf( "ERROR: Could not read input yuv file '%s'\n", osd_files[5*i] ); 
                  return(64); 
          }
        }
#endif 
 
        printf("Reading YUV Input.\n");
        // Read YUV file contents into the input frame buffer:
        if (read_yuv(input_fid[i], &yuv_layer_video[i])>0) 
        { 
          printf( "ERROR: Could not read input yuv file '%s'\n", osd_files[5*i] ); 
                return(64); 
        }

        //Copy data to input layer buffer
        printf("Copying YUV buffer to Video buffer.\n");
        copy_yuv_to_video(&yuv_layer_video[i], &inputs.video_in[i]);
      }
    }
  }

  // Create state
  state = xilinx_ip_v_osd_v6_0_create_state(generics);
  if (state == NULL) {
    printf("ERROR: could not create state object\n");
    return 1;
  }

  // Create input data frame: constant data
  // Set data in the inputs structure to hard-coded constant values

  // Simulate the core
  printf("Running the C model...\n");
  if (xilinx_ip_v_osd_v6_0_bitacc_simulate(state, inputs, &outputs) != 0) {
    printf("ERROR: simulation did not complete successfully\n");
    return 1;
  } else {
    printf("Simulation completed successfully\n");
  }
  // Check outputs are correct
  //
  
  ///////////////////////////////////////////////////////////////////////////////
  //  open new image output file //
  ///////////////////////////////////////////////////////////////////////////////
  if (OSD_DEBUG) printf("Opening Output File '%s'...\n", osd_files[5*OSD_MAX_LAYERS]);
  if ( (output_fid = fopen(osd_files[5*OSD_MAX_LAYERS], "wb")) == NULL ) 
  {
    printf( "ERROR: Could not open output yuv file '%s'\n", osd_files[5*OSD_MAX_LAYERS]); return(8); 
  }

  if(inputs.color_space == FORMAT_RGB)
  {
    //Copy output data to rgb structure for writing rgb file out
    if (OSD_DEBUG) printf("Copying Video Struct to rgb struct\n");
    copy_video_to_rgb8(&outputs.video_out, &rgb8_out_video);
  }
  else
  {
    //Copy output data to yuv structure for writing yuv file out
    if (OSD_DEBUG) printf("Copying Video Struct to YUV struct\n");
    copy_video_to_yuv8(&outputs.video_out, &yuv_out_video444);
  }

#if 0
  if(inputs.color_space == FORMAT_C422)
  {

        //Setup YUV Input buffer for layer i
        yuv8_tmp_video.frames          = inputs.num_frames;
        yuv8_tmp_video.rows            = screen_max_y; //inputs.frame_cfg->y_size;
        yuv8_tmp_video.cols            = screen_max_x; //inputs.frame_cfg->x_size;
        yuv8_tmp_video.chroma_format   = FORMAT_C422;
        yuv8_tmp_video.bits_per_component = generics.C_DATA_WIDTH;
        yuv8_tmp_video.y               = NULL;
        yuv8_tmp_video.u               = NULL;
        yuv8_tmp_video.v               = NULL;

    if(OSD_DEBUG) printf("Allocating YUV buffer for Output...\n");
    if(alloc_yuv8_frame_buff(&yuv8_tmp_video) > 0) 
    {
      printf("ERROR: Cannot Allocating Memory\n");
      free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_tmp_video);
      return(128);
    }


    if (OSD_DEBUG) printf("Copying YUV 444 to 422 struct\n");
    if(yuv8_444to422(&yuv8_out_video444, &yuv8_tmp_video) > 0) 
    {
      printf("ERROR: Cannot Convert output YUV 444 to 422\n");
      return(129);
    }
  }
  else if(inputs.color_space == FORMAT_C420)
  {

        //Setup YUV Input buffer for layer i
        yuv8_tmp_video.frames          = inputs.num_frames;
        yuv8_tmp_video.rows            = screen_max_y; //inputs.frame_cfg->y_size;
        yuv8_tmp_video.cols            = screen_max_x; //inputs.frame_cfg->x_size;
        yuv8_tmp_video.chroma_format   = FORMAT_C420;
        yuv8_tmp_video.bits_per_component = generics.C_DATA_WIDTH;
        yuv8_tmp_video.y               = NULL;
        yuv8_tmp_video.u               = NULL;
        yuv8_tmp_video.v               = NULL;

    if(OSD_DEBUG) printf("Allocating YUV buffer for Output...\n");
    if(alloc_yuv8_frame_buff(&yuv8_tmp_video) > 0) 
    {
      printf("ERROR: Cannot Allocating Memory\n");
      free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_tmp_video);
      return(128);
    }


    if (OSD_DEBUG) printf("Copying YUV 444 to 420 struct\n");
    if(yuv8_444to420(&yuv8_out_video444, &yuv8_tmp_video) > 0 )
    {
      printf("ERROR: Cannot Convert output YUV 444 to 420\n");
      return(129);
    }


  }
#endif
  printf("Writing Output Data to '%s' cs=%d...\n", osd_files[5*OSD_MAX_LAYERS],inputs.color_space);
  if (inputs.color_space == FORMAT_C444) 
  {
    if(write_yuv8(output_fid, &yuv_out_video444)>0)
    {
      printf( "WARNING: Could not write to output yuv 444 file '%s'\n", osd_files[5*OSD_MAX_LAYERS]); 
      ret_val=128; 
    }
  }
  else if (inputs.color_space == FORMAT_RGB) 
  {
    if(write_bmp(output_fid, &rgb8_out_video)>0)
    { 
      printf( "WARNING: Could not write to output bmp file '%s'\n", osd_files[5*OSD_MAX_LAYERS]); 
      ret_val=128; 
    }
  }
  //else if (write_yuv8(output_fid, &yuv8_tmp_video)>0) 
  else if (write_yuv8(output_fid, &yuv_out_video444)>0) 
  {
    printf( "WARNING: Could not write to output yuv 42x file '%s'\n", osd_files[5*OSD_MAX_LAYERS]); 
    ret_val=128; 
  }


#ifdef CREATE_STIMULUS
  if(setup_mode & 0x01) // If generate Stimulus bit set
  {
    /////////////////////////////////////////////////////////////////////////
    // Video output
    /////////////////////////////////////////////////////////////////////////
#ifdef NT
    mkdir("expected");
#else
    mkdir("expected", 0755);
#endif
 
      frame_cfg_ptr = inputs.frame_cfg;
      for(frame=0; frame<inputs.num_frames; frame++)
      {
        printf("Writing output expected data frame %d (%d x %d)\n", frame+1, frame_cfg_ptr->x_size, frame_cfg_ptr->y_size);

        if(frame == 0)
        {
          sprintf(osd_expected_filename, "%s", osd_expected_file);
        }
        else
        {
          sprintf(osd_expected_filename, "%s.%03d", osd_expected_file, frame);
        }

        if (OSD_DEBUG) printf("Opening Simulation expected File '%s'...\n", osd_expected_filename);
        if ( (osd_expected_fid = fopen(osd_expected_filename, "w")) == NULL ) 
        {
          printf( "ERROR: Could not open output expected file '%s'\n", osd_expected_filename); return(8); 
        }
        WriteVideoTxtFile(osd_expected_fid, &outputs.video_out, frame, frame_cfg_ptr->y_size, frame_cfg_ptr->x_size);
        fclose(osd_expected_fid);

        if(frame_cfg_ptr->next != NULL)
        {
          frame_cfg_ptr = frame_cfg_ptr->next;
        }
      }

#if 0
    // Write the OSD model output to expected file
    if(   (inputs.color_space == FORMAT_RGB) || (inputs.color_space == FORMAT_C444)
       || (inputs.color_space == FORMAT_RGB_A) || (inputs.color_space == FORMAT_C444_A))
    {
      frame_cfg_ptr = inputs.frame_cfg;
      for(frame=0; frame<inputs.num_frames; frame++)
      {
        printf("Writing output expected data frame %d (%d x %d)\n", frame+1, frame_cfg_ptr->x_size, frame_cfg_ptr->y_size);
        WriteVideoTxtFile(osd_expected_fid, &outputs.video_out, frame, frame_cfg_ptr->y_size, frame_cfg_ptr->x_size);
        frame_cfg_ptr = frame_cfg_ptr->next;
      }
    }
    else
    {
          // YUV
          if(OSD_DEBUG)
          {
                  printf("expected Video # of frames = %d.\n", yuv8_tmp_video.frames); 
                  printf("expected Video # of rows   = %d.\n", yuv8_tmp_video.rows); 
                  printf("expected Video # of cols   = %d.\n", yuv8_tmp_video.cols); 
                  printf("expected Video mode        = %d.\n", yuv8_tmp_video.chroma_format); 
                  printf("expected Video bpc         = %d.\n", yuv8_tmp_video.bits_per_component); 

          }
          video_stimulus_out.frames          = yuv8_tmp_video.frames;
          video_stimulus_out.rows            = yuv8_tmp_video.rows;
          video_stimulus_out.cols            = yuv8_tmp_video.cols;
          video_stimulus_out.mode            = yuv8_tmp_video.chroma_format;
          video_stimulus_out.bits_per_component = yuv8_tmp_video.bits_per_component;

          video_stimulus_out.data[0] = NULL;
          video_stimulus_out.data[1] = NULL;
          video_stimulus_out.data[2] = NULL;
          video_stimulus_out.data[3] = NULL;

          if(alloc_video_buff(&video_stimulus_out) > 0) 
          {
            printf("ERROR: Cannot Allocate Video Memory For Stimulus\n");
            free_video_buff(&video_stimulus_out);
            return(128);
          }

          copy_yuv8_to_video(&yuv8_tmp_video, &video_stimulus_out);

          frame_cfg_ptr = inputs.frame_cfg;
          for(frame=0; frame<inputs.num_frames; frame++)
          {
            WriteVideoTxtFile(osd_expected_fid, &video_stimulus_out, frame, frame_cfg_ptr->y_size, frame_cfg_ptr->x_size);
            frame_cfg_ptr = frame_cfg_ptr->next;
          }  
          free_video_buff(&video_stimulus_out);
    }
#endif
  }  
#endif

  // Compare data in the outputs structure to hard-coded expected outputs
  ok = 1;
  // For any mismatches, report an error and set ok to false

  // That's all of the checks done
  if (ok) {
    printf("Outputs from simulation are correct\n");
  } else {
    printf("Some outputs from simulation are incorrect\n");
  }

  // Destroy the state to free up memory
  xilinx_ip_v_osd_v6_0_destroy_state(state);
  // Free Layer Buffers  
  for(i=0; i < generics.C_NUM_LAYERS; i++)
  {
    if(inputs.layer_cfg[i]->chan_mode[0] == OSD_PREFILL_MODE)
    {
      printf("Freeing Layer YUV Buffer #%d...\n", i);
      free_yuv_frame_buff((struct yuv_video_struct*)&yuv_layer_video[i]);
    }
    printf("Freeing Layer Video Buffer #%d...\n", i);
    free_video_buff(&inputs.video_in[i]);
  }
  printf("Freeing Output Buffer...\n");
  free_yuv_frame_buff((struct yuv_video_struct*)&yuv_out_video444);
  //free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_tmp_video);
  free_video_buff(&outputs.video_out);
  
  printf("Exiting...\n");
  // Return value indicates if all outputs were correct
  if (ok) {
    return 0;
  } else {
    return 1;
  }

}
